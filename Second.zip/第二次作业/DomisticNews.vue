<template>
  <div class="domestic-news">
    <h2>国内新闻</h2>
    <button @click="toggleContent">
      {{ showContent ? '隐藏内容' : '显示内容' }}
    </button>

    <div v-if="showContent" class="news-content">
      <p>据新华社报道，我国经济持续稳定增长……</p>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      showContent: false // 初始状态为隐藏
    }
  },
  methods: {
    toggleContent() {
      this.showContent = !this.showContent // 切换显示状态
    }
  }
}
</script>

<style scoped>
.domestic-news {
  padding: 20px;
}

button {
  padding: 8px 16px;
  cursor: pointer;
  margin-bottom: 10px;
}

.news-content {
  border: 1px solid #ddd;
  padding: 15px;
  background-color: #f9f9f9;
}
</style>
