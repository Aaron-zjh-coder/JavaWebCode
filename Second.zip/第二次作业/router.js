import { createRouter, createWebHistory } from 'vue-router'
import Login from "@/components/Login.vue"
import Home from "@/components/Home.vue"

const routes = [
    {
        path: '/',
        name: 'Login',
        component: Login
    },
    {
        path: '/home',
        name: 'Home',
        component: Home,
        children: [
            {
                path: 'domestic',
                component: () => import('@/components/DomisticNews.vue')
            },
            {
                path: 'international',
                component: () => import('@/components/InternationalNews.vue')
            }
        ]
    }
]

const router = createRouter({
    history: createWebHistory(),
    routes
})

export default router
