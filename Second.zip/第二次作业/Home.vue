<template>
  <div>
    <div class="home-container">
      <h3>{{ username }}---欢迎光临</h3>
      <div class="nav-links">
        <router-link to="home/domestic">国内新闻</router-link>
        <router-link to="home/international">国际新闻</router-link>
      </div>
      <router-view></router-view>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      username: 'admin'
    }
  }
}
</script>

<style scoped>
.home-container {
  margin-top: 20px;
}

.nav-links a {
  margin-right: 20px;
  text-decoration: none;
  color: #333;
}
</style>
