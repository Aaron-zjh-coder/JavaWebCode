<template>
  <div class="international-news">
    <h2>国际新闻</h2>
    <button @click="toggleContent">
      {{ showContent ? '隐藏内容' : '显示内容' }}
    </button>

    <div v-if="showContent" class="news-content">
      <p>联合国最新报告显示，全球气候变暖趋势持续加剧……</p>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      showContent: false
    }
  },
  methods: {
    toggleContent() {
      this.showContent = !this.showContent
    }
  }
}
</script>

<style scoped>
.international-news {
  padding: 20px;
}

button {
  padding: 8px 16px;
  cursor: pointer;
  margin-bottom: 10px;
}

.news-content {
  border: 1px solid #ddd;
  padding: 15px;
  background-color: #f9f9f9;
}
</style>
