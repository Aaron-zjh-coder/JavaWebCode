<template>
  <div class="login-container">
    <label for="username">账号</label>
    <input id="username" v-model="username" type="text"/>

    <label for="password">密码</label>
    <input id="password" v-model="password" type="password"/>

    <button @click="login">登录</button>
    <button @click="register">注册</button>

    <p v-if="errorMessage" style="color: red;">{{ errorMessage }}</p>
  </div>
</template>

<script>
export default {
  data() {
    return {
      username: "",
      password: "",
      errorMessage: ""
    }
  },
  methods: {
    login() {
      if (this.username === 'admin' && this.password === '123456') {
        this.$router.push('/home')
      } else {
        this.errorMessage = '用户名或密码错误'
      }
    },
    register() {
      this.$router.push('/register')
    }
  }
}
</script>

<style scoped>
.login-container {
  width: 100%;
  height: 100%;
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 20px;
}

.login-container label {
  margin: 10px;
}

.login-container input {
  margin: 10px;
  padding: 5px;
}

.login-container button {
  margin: 10px;
  padding: 5px;
}
</style>
